<?php
echo "PHP script received:\n\nGET: ";
echo var_dump($_GET);
echo "\nPOST: ";
echo var_dump($_POST);
?>