btnScript2.onfocus = function() {
    alert("Button has been focussed");
}


